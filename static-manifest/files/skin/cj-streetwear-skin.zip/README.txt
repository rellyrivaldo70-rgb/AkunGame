NETRALHUB Demo Skin Pack
Pack Name: CJ Streetwear Skin

Ini adalah template paket demo untuk skin player.
Ganti file placeholder di bawah dengan file mod milikmu sendiri sebelum dipakai di server production.

Contoh struktur yang umum:
- cj.dff
- cj.txd

Setelah isi paket diganti, generate ulang modlist.json supaya hash file cocok.
