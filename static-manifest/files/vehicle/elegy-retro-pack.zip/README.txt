NETRALHUB Demo Vehicle Pack
Pack Name: Elegy Retro Pack

Isi folder ini adalah template paket demo untuk static manifest mode.
Ganti file placeholder di bawah dengan file mod GTA SA milikmu sendiri sebelum dipakai di server production.

Contoh struktur yang umum:
- elegy.dff
- elegy.txd
- vehicle.ide patch

Catatan:
- File demo ini aman untuk contoh karena tidak menyertakan asset pihak ketiga.
- Setelah kamu ganti isi paket, generate ulang modlist.json agar hash berubah sesuai file asli.
